% This script trains a mixture of gaussians model for butterfly classification.
% One mixture of gaussians is formed from the foreground pixels inside
% the crops in the training set, while another is trained from the
% background pixels outside the crops.
%
% NOTE:
% In the code below,
% fg = foreground
% bg = gackground
%
% Code by Michael Firman except where marked otherwise

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SETUP
clear
clc
close all
addpath('emgm')

% setting training paths
training_data_path = '../data/train/';
training_data_filename = '../data/train.mat';
addpath('emgm')

% setting training parameter values
number_of_gaussians = 6;
number_of_training_pixels = 300000;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  EXTRACTING TRAINING PIXELS FROM IMAGES

% load in the csv data and convert to the format we want
filedata = load(training_data_filename);

% for each training image, extract the foreground and background pixels
fg_pixels = zeros(0, 3);
bg_pixels = zeros(0, 3);

N = length(filedata.crops);

for ii = 1:N
    
    disp(['Extracting pixels from image ', num2str(ii), ' of ', num2str(N)]);
    
    % load in the image
    impath = [training_data_path, filedata.image_names{ii}];
    im = imread(impath);
    
    % create the mask
    % (Note that we treat foreground as anything inside the bounding box)
    bbox = filedata.crops(ii, :);
    mask_size = [size(im, 1), size(im, 2)];
    mask = bounding_box_to_mask(bbox, mask_size);
    
    % convert the image to a list of pixels
    pixels = pixel_list(im);
    
    % extract foreground and background pixels
    fg = pixels(mask(:)==1, :);
    bg = pixels(mask(:)==0, :);
    
    % add these to the main arrays
    fg_pixels = [fg_pixels; fg];
    bg_pixels = [bg_pixels; bg];
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FITTING MIXTURE OF GAUSSIAN MODELS

% Take random subset of the foreground and background pixels for computational efficiency
fg_pixels = subsample_rows(fg_pixels, number_of_training_pixels);
bg_pixels = subsample_rows(bg_pixels, number_of_training_pixels);

% Convert pixel values to double
fg_pixels = double(fg_pixels);
bg_pixels = double(bg_pixels);

% fit mixture of gaussians model to the foreground, and one to the background
[~, fg_model, ~] = emgm(fg_pixels', number_of_gaussians);
[~, bg_model, ~] = emgm(bg_pixels', number_of_gaussians);

% save the models to disk
save('../data/model.mat', 'fg_model', 'bg_model')

% test accuracy
target = [ ones(length(fg_pixels),1); zeros(length(bg_pixels), 1)];

fg_prior = 0.3;
bg_prior = 0.7;
fg_lh = exp(likelihood(fg_pixels', fg_model));
bg_lh = exp(likelihood(fg_pixels', bg_model));

% use bayes, with the prior, to find a posterior
partition = fg_lh * fg_prior + bg_lh * bg_prior;
posterior = (fg_lh * fg_prior) ./ partition;


correct_fg = sum(posterior>0.5);
fg_lh = exp(likelihood(bg_pixels', fg_model));
bg_lh = exp(likelihood(bg_pixels', bg_model));

% use bayes, with the prior, to find a posterior
partition = fg_lh * fg_prior + bg_lh * bg_prior;
posterior = (fg_lh * fg_prior) ./ partition;
correct_bg = sum(posterior<=0.5);

accuracy = (correct_fg + correct_bg)/(length(fg_pixels) + length(bg_pixels))


function T = likelihood(X, model)
mu = model.mu;
Sigma = model.Sigma;
w = model.weight;

n = size(X,2);
k = size(mu,2);
logRho = zeros(n,k);

for i = 1:k
    logRho(:,i) = loggausspdf(X,mu(:,i),Sigma(:,:,i));
end
logRho = bsxfun(@plus,logRho,log(w));
T = logsumexp(logRho,2);
end

function y = loggausspdf(X, mu, Sigma)
d = size(X,1);
X = bsxfun(@minus,X,mu);
[U,p]= chol(Sigma);
if p ~= 0
    error('ERROR: Sigma is not PD.');
end
Q = U'\X;
q = dot(Q,Q,1);  % quadratic term (M distance)
c = d*log(2*pi)+2*sum(log(diag(U)));   % normalization constant
y = -(c+q)/2;

end


