function box_im = getImInBox(im, box)

box_im = im(box(3):box(4), box(1):box(2), :);

end