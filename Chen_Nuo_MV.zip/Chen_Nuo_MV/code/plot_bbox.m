function plot_bbox(bbox, col, label)
    % plots the bounding box to the current axis
    % bbox is [left, right, top, bottom]
    
    hold('on')
    plot([bbox(1), bbox(2)], [bbox(3), bbox(3)], col, 'linewidth', 2)
    plot([bbox(1), bbox(2)], [bbox(4), bbox(4)], col, 'linewidth', 2)
    plot([bbox(1), bbox(1)], [bbox(3), bbox(4)], col, 'linewidth', 2)
    plot([bbox(2), bbox(2)], [bbox(3), bbox(4)], col, 'linewidth', 2)
    
    text(bbox(1), bbox(3) - 10, label)
    hold('off')
    
    
end