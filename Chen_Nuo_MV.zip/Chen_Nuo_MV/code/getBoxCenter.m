function [centerx,centery] = getBoxCenter(box)
centerx = floor(0.5*(box(4)+box(3)));
centery = floor(0.5*(box(2)+box(1)));
end