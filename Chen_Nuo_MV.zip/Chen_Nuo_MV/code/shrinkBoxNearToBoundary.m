function newBox = shrinkBoxNearToBoundary(box, imH, imL)
left = max(box(1), 0.125*imL);
right = min(box(2), 0.875*imL);
low = max(box(3), 0.125*imH);
high = min(box(4), 0.875*imH);

newBox = [left,right,low,high];
end