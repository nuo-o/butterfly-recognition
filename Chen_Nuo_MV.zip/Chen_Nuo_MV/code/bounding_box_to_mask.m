function mask = bounding_box_to_mask(bbox, imsize)
    % converts bounding box [left right top bottom] to a binary mask the same
    % size as imsize
     
    left = bbox(1);
    right = bbox(2);
    top = bbox(3);
    bottom = bbox(4);
    
    mask = zeros(imsize);
    mask(top:bottom, left:right) = 1;
    
end