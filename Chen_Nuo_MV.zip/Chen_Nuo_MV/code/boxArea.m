function area = boxArea(predicted_bbox)
area = (predicted_bbox(4)-predicted_bbox(3) ) * ( predicted_bbox(2) - predicted_bbox(1));
end