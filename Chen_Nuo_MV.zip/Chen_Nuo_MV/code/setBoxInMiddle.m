function middleBox = setBoxInMiddle(imH, imL, Hpropoortion, Lproportion)
low = floor(imH * Hpropoortion);
high = floor( imH * (1-Hpropoortion));
left = floor(imL * Lproportion);
right = floor(imL* (1-Lproportion));
middleBox = [left, right, low, high];
end