function predicted_bbox = mergeMultipleCandidateBox(candidate_box, imH,imL)

if size(candidate_box,1) ==2
    
    [~,target_box] = max( [boxArea(candidate_box(1,:,:,:)), boxArea(candidate_box(2,:,:,:))]);
    predicted_bbox = candidate_box(target_box,:,:,:);
    
else
    
    [centerx,centery] = getBoxCenter([0, imL, 0, imH]);
    dist = [];
    
    for box = candidate_box'
        
        [boxCenterX,boxCenterY] = getBoxCenter(box);
        X = [centerx, centery; boxCenterX, boxCenterY];
        dist = [dist;pdist(X,'euclidean')];
        
    end
    
    meanDist = mean(dist);
    [indexDist, ~] = find(dist > 1.5*meanDist);
    candidate_box(indexDist,:,:,:) = [];
    
    overlapping_boxes_mask = zeros(imH,imL);
    
    for box = candidate_box'
        overlapping_boxes_mask(box(3):box(4), box(1):box(2)) = 1;
    end
    
    predicted_bbox = getBoxOfLargestComponent(overlapping_boxes_mask);
    
end
end