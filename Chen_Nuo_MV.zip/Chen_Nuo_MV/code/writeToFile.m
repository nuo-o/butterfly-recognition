function random_file_name = writeToFile(file,savePath, fileExt, filetype, currentFolder)

random_file_name = tempname;
[~, random_file_name] = fileparts(random_file_name);
random_file_name = [random_file_name, fileExt ];
cd(savePath)
imwrite( file, random_file_name, filetype);
cd(currentFolder)

end