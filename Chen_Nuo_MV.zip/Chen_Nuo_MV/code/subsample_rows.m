function subsampled_mat = subsample_rows(mat, n)
    % returns n random rows from mat
    
    N = size(mat, 1);
    
    if N <= n
        subsampled_mat = mat;
    else
        idxs = randperm(N, n);
        subsampled_mat = mat(idxs, :);
    end

end