function [near,dist] = isBoxNearCenter(imH,imL,box, threshold)

[centerx1,centery1] = getBoxCenter(box);
[centerx2,centery2] = getBoxCenter([0, imL, 0, imH]);
X = [centerx1,centery1;centerx2,centery2 ];
dist = pdist(X,'euclidean') ;
boxsize = min(box(2)-box(1), box(4)-box(3));

if dist <= threshold*boxsize
    near = 1;
else
    near = 0;
end

end