function discard = isBoxNearBoundary(bbox1, imH, imL)
discard = 0;
bbox1 = double(bbox1);
bbox2 = double([0.125*imL,0.725*imL, 0.125*imH, 0.875*imH]);

% first compute the left, right, top, bottom of the intersection rectangle
intersection = zeros(1, 4);
intersection(1) = max(bbox1(1), bbox2(1));
intersection(2) = min(bbox1(2), bbox2(2));
intersection(3) = max(bbox1(3), bbox2(3));
intersection(4) = min(bbox1(4), bbox2(4));
intersection_area = box_area(intersection);
if intersection_area <= 0.5* boxArea(bbox1)
    discard = 1;
end
end

function area = box_area(bbox)
    % computes the area of a bounding box defined by (left, right, top, bottom)
    % (This will be zero if the coordinates are invalid)
    
    left = bbox(1);
    right = bbox(2);
    top = bbox(3);
    bottom = bbox(4);
    
    % If left > right or top > bottom, then set area to zero,
    % don't let area be negative!
    if left > right
        area = 0;
    elseif top > bottom
        area = 0;
    else
        area = (right - left) * (bottom - top);
    end

end



% function fall = isBoxNearBoundary(predicted_bbox, imH, imL, threshold)
% fall = 0;
% left = predicted_bbox(1);
% right = predicted_bbox(2);
% low = predicted_bbox(3);
% high = predicted_bbox(4);
%
% if left<=(1+threshold) || right >= (imL-threshold) || low<=(1+threshold) || high >= (imH-threshold)
%     fall = 1;
% end
% end