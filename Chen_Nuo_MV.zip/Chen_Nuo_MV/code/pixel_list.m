function pixels = pixel_list(im)
    % converts n x m x 3 image into a nm x 3 array of pixels
    
    tmp = permute(im, [3, 1, 2]);
    pixels = reshape(tmp, 3, [])';
    
end