function predicted_bbox = getBoxOfLargestComponent( overlapping_boxes_mask)

component = bwlabel(overlapping_boxes_mask);
counts = accumarray(1+ component(:), 1);
counts(1) = 0;
[~, max_region] = max(counts);
binary_image_depicting_max_region = component == (max_region-1);
predicted_bbox = mask_to_bounding_box(binary_image_depicting_max_region);

end