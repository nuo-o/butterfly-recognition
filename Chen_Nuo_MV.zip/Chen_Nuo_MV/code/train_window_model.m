clear;clc;close all;addpath('emgm');

% parameters
training_data_path = '../data/train/';
training_data_filename = '../data/train.mat';
filedata = load(training_data_filename);
N = length(filedata.image_names);
POSTERIOR_THRESHOLD_RANGES = [0.3, 0.5, 0.6, 0.7];
RESIZE_IMAGE_SIZE = [64,64];
IOU_THRESHOLD = 0.6;


% MOG model
% load('../data/model.mat');
load('../data/model.mat');
fg_prior = 0.3;

X = [];
ious = [];
for ii = 1:N
    disp(['Processing pixels from image ', num2str(ii), ' of ', num2str(N)])
    impath = [training_data_path, filedata.image_names{ii}];
    im = imread(impath);
    
    posterior_im = classify_pixels_using_mog_model(im, fg_model, bg_model, fg_prior);
    
    ground_truth_bbox = double(filedata.crops(ii, :));
    
    [boxes, cur_iou] = getPosteriorCC(posterior_im, POSTERIOR_THRESHOLD_RANGES, ground_truth_bbox);
    ious = [ious;cur_iou];
    
    % extract image features
    
    for box = boxes'
        
        box_im = getImInBox(im, box);
        histeq_im = histeq(box_im);
        mean_R = mean(mean(histeq_im(:,:,1)));
        mean_G = mean(mean(histeq_im(:,:,2)));
        mean_B = mean(mean(histeq_im(:,:,3)));
        gray = rgb2gray(histeq_im);
        resized = imresize(gray, RESIZE_IMAGE_SIZE);
        hog = extractHOGFeatures(resized);
        edge_feature = reshape(edge(resized), [1,RESIZE_IMAGE_SIZE(1)*RESIZE_IMAGE_SIZE(2)]);
%         cur_feature = [edge_feature, mean_R, mean_G, mean_B];
        cur_feature = [hog, edge_feature, mean_R,mean_G,mean_B];
        X = [X;cur_feature];
        
    end
end

Y = [ious > IOU_THRESHOLD ];
classifier = fitctree(X,Y);
saveCompactModel(classifier,'../data/HOG.mat');
classifier = fitcsvm(X, Y);
saveCompactModel(classifier,'../data/HOG_SVM.mat');
loss_val = resubLoss(classifier)

