function [boxes, ious] = getPosteriorCC(posterior_im, THRESHOLDS, true_box)

boxes = [];
ious = [];
[imH,imL] = size(posterior_im);
for threshold = THRESHOLDS
    % find the largest connected component in thresholded posterior image
    thresholded_posterior = (posterior_im >= threshold);
    post_thresh = bwlabel(thresholded_posterior);
    counts = accumarray(1+ post_thresh(:), 1);
    counts(1) = 0;
    region_labels = find(counts > 500);
    
    
    for r =1: size(region_labels,1)
        
        binary_image_depicting_max_region = (post_thresh == (region_labels(r) -1));
        cur_box = mask_to_bounding_box(binary_image_depicting_max_region);
        cur_iou = compute_iou(cur_box, true_box);
        
        boxes = [boxes; cur_box];
        ious = [ious;cur_iou];
        
    end
end