clear;clc;close all;addpath('emgm');

% To chage different test data, please edit here
testing_data_path = '../data/test/';
testing_data_filename = '../data/test.mat';
results_path = '../data/results/';

% load model
load('../data/model.mat');
Mdl = loadCompactModel('../data/HOG_SVM.mat'); % for classify box window
filedata = load(testing_data_filename);
N = length(filedata.image_names);

% parameters
fg_prior = 0.3;
POSTERIOR_THRESHOLD_RANGES = [0.3, 0.5, 0.6, 0.7, 0.8];
RESIZE_IMAGE_SIZE = [64,64];
all_ious = zeros(N,1);

for ii = 1:N
    
    disp(['Processing pixels from image ', num2str(ii), ' of ', num2str(N)])
    impath = [testing_data_path, filedata.image_names{ii}];
    im = imread(impath);
    
    %% use MOG model to get box proposal
    posterior_im = classify_pixels_using_mog_model(im, fg_model, bg_model, fg_prior);
    
    ground_truth_bbox = double(filedata.crops(ii, :));
    
    [boxes, cur_iou] = getPosteriorCC(posterior_im, POSTERIOR_THRESHOLD_RANGES, ground_truth_bbox);
    
    candidate_box = [];
    near_center_box = [];
    [imH, imL, ~] = size(im);
    
    for box = boxes'
        
        if isBoxNearBoundary(box, imH, imL)
            continue;
        end
        
        % extract features
        box_im = getImInBox(im, box);
        histeq_im = histeq(box_im);
        mean_R = mean(mean(histeq_im(:,:,1)));
        mean_G = mean(mean(histeq_im(:,:,2)));
        mean_B = mean(mean(histeq_im(:,:,3)));
        gray = rgb2gray(histeq_im);
        resized = imresize(gray, RESIZE_IMAGE_SIZE);
        hog = extractHOGFeatures(resized);
        edge_feature = reshape(edge(resized), [1,RESIZE_IMAGE_SIZE(1)*RESIZE_IMAGE_SIZE(2)]);
        cur_feature = [hog, edge_feature, mean_R,mean_G,mean_B];
        
        %% use window classifier to propose candidate box
        predict_label = predict( Mdl, cur_feature);
        
        % add box as candidate if it passes the window classifier
        if predict_label ==1           
        
            box = shrinkBoxNearToBoundary(box, imH, imL);
            candidate_box = [candidate_box; box];
       
        end
        
        % add box as candidate if it doesn't pass the window classifier but
        % is near to the center
        [near, dist] = isBoxNearCenter(imH,imL,box',0.5);
        
        if near
            
            box = shrinkBoxNearToBoundary(box, imH, imL);
            near_center_box = [near_center_box;box];
            
        end
    end
    
    %% find predicted box based on candidate_box and near_center_box
    if size(candidate_box,1) == 0
        
        if size(near_center_box,1) >0
            
            candidate_box = near_center_box;
            
        else
            
            predicted_bbox = setBoxInMiddle(imH, imL, 0.25, 0.33);
            
        end
    end
    
    % if only one candidate box, consider if it is valid based on its
    % distance to the image center, otherwise, take near_center_box into
    % account
    if size(candidate_box,1) == 1
        
        box = candidate_box;
        [centery,centerx] = getBoxCenter(box);
        [centerImX, centerImY] = getBoxCenter([0,imL,0,imH]);
        box_len = min(box(4)-box(3), box(2)-box(1));
        
        [near,~] = isBoxNearCenter(imH,imL,box,0.6);
        
        if near
            
            predicted_bbox = box;
            
        elseif size(near_center_box,1) ==1
            
            predicted_bbox = near_center_box;
            
        else
            
            candidate_box = near_center_box;
            
        end
    end
    
    % if there are more than one candidate box, merge them
    if size(candidate_box, 1) >1
        
        predicted_bbox = mergeMultipleCandidateBox(candidate_box, imH,imL);
    
    end
    
    
    predicted_bbox = shrinkBoxNearToBoundary(predicted_bbox, imH, imL);
    
    % discard boxes that are too large, or too far away form the 
    if boxArea(predicted_bbox) >= 0.8*imH*imL || ~isBoxNearCenter(imH, imL, predicted_bbox, 1.5)
        
        predicted_bbox = setBoxInMiddle(imH, imL, 0.25,0.33);
        
    end
    
    %% evaluate the result
    predicted_iou = compute_iou(ground_truth_bbox, predicted_bbox);
    disp(['IoU is ', num2str(predicted_iou)])
    all_ious(ii) = predicted_iou;
    
    % save results figures
    h = figure();
    set(h, 'Visible', 'off')
    
    subplot(221)
    imshow(im)
    title('Input image')
    
    subplot(222)
    imshow(posterior_im);

    title('posterior image')
    
    subplot(223)
    imshow(im)
    for box=near_center_box'
        plot_bbox(box,'g', ' ');
    end
    for box=candidate_box'
        plot_bbox(box, 'y', ' ');
    end
    title('Near Center Boxes(Green), Candidate Boxes(Yellow)')
    
    subplot(224)
    imshow(im)
    plot_bbox(ground_truth_bbox, 'r', 'Ground truth')
    plot_bbox(predicted_bbox, 'b', 'Predicted')
    title(['Prediction: IoU = ', num2str(predicted_iou)])
    
    savename = [results_path, filedata.image_names{ii}];
    saveas(h, savename)
    disp(['Saving results image to ', savename])
    
end


disp('----------------------')
disp('Average IoU is:')
disp(mean(all_ious))


load handel
sound(y,Fs)