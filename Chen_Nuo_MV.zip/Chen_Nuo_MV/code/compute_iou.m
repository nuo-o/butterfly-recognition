function iou_ratio = compute_iou(bbox1, bbox2)
    % computes the intersection over union between two bounding boxes
    % each bounding box is a matrix consisting of (left right top bottom)
    % values.
    
    % ensure no integer values
    
    bbox1 = double(bbox1);
    bbox2 = double(bbox2);
    
    % first compute the left, right, top, bottom of the intersection rectangle
    intersection = zeros(1, 4);
    intersection(1) = max(bbox1(1), bbox2(1));
    intersection(2) = min(bbox1(2), bbox2(2));
    intersection(3) = max(bbox1(3), bbox2(3));
    intersection(4) = min(bbox1(4), bbox2(4));
    
    
    % now find the area of the intersection
    % (This will be zero if the bounding boxes don't overlap at all)
    intersection_area = box_area(intersection);
    
    % now find area of each bounding box
    area1 = box_area(bbox1);
    area2 = box_area(bbox2);
   
    
    % now use all this to compute the union
    union_area = area1 + area2 - intersection_area;
    
    % now finally the iou ratio
    iou_ratio = intersection_area / union_area;
        
end



function area = box_area(bbox)
    % computes the area of a bounding box defined by (left, right, top, bottom)
    % (This will be zero if the coordinates are invalid)
    
    left = bbox(1);
    right = bbox(2);
    top = bbox(3);
    bottom = bbox(4);
    
    % If left > right or top > bottom, then set area to zero,
    % don't let area be negative!
    if left > right
        area = 0;
    elseif top > bottom
        area = 0;
    else
        area = (right - left) * (bottom - top);
    end

end