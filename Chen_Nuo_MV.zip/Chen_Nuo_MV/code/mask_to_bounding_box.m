function bbox = mask_to_bounding_box(mask)
    % converts a binary mask to a bounding box
    
    left = find(any(mask, 1), 1, 'first');
    right = find(any(mask, 1), 1, 'last');
    
    top = find(any(mask, 2), 1, 'first');
    bottom = find(any(mask, 2), 1, 'last');
    
    bbox = [left, right, top, bottom];
    
end