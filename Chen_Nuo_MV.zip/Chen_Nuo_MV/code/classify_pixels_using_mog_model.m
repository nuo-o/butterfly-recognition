function posterior_image = classify_pixels_using_mog_model(im, fg_model, bg_model, fg_prior)
    % Classify each pixel in an image according to the mixture of Gaussians
    % models for the foreground and background.
    % Returns a posterior, making use of the provided prior.
    
    bg_prior = 1.0 - fg_prior;
    
    % convert the image to an array of pixels
    im_as_pixels = double(pixel_list(im));
    
    % get the likelihood under the fg and bg models
    fg_lh = exp(likelihood(im_as_pixels', fg_model));
    bg_lh = exp(likelihood(im_as_pixels', bg_model));
    
    % use bayes, with the prior, to find a posterior
    partition = fg_lh * fg_prior + bg_lh * bg_prior;
    posterior = (fg_lh * fg_prior) ./ partition;
    
    % convert posterior back to an image
    posterior_image = reshape(posterior, [size(im, 1), size(im, 2)]);

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The following functions were adapted from emgm/emgm.m

function T = likelihood(X, model)
mu = model.mu;
Sigma = model.Sigma;
w = model.weight;

n = size(X,2);
k = size(mu,2);
logRho = zeros(n,k);

for i = 1:k
    logRho(:,i) = loggausspdf(X,mu(:,i),Sigma(:,:,i));
end
logRho = bsxfun(@plus,logRho,log(w));
T = logsumexp(logRho,2);
end

function y = loggausspdf(X, mu, Sigma)
d = size(X,1);
X = bsxfun(@minus,X,mu);
[U,p]= chol(Sigma);
if p ~= 0
    error('ERROR: Sigma is not PD.');
end
Q = U'\X;
q = dot(Q,Q,1);  % quadratic term (M distance)
c = d*log(2*pi)+2*sum(log(diag(U)));   % normalization constant
y = -(c+q)/2;

end